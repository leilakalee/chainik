package com.trialone;

public interface Observer {
    void NewRelease();

    void receiveNewspaper();

    void subscribePhouse(PublishersHouse pHouseName);
}
