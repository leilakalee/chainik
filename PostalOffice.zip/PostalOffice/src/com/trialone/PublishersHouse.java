package com.trialone;

import java.util.ArrayList;
import java.util.List;

public class PublishersHouse {
    List<Subscribers> subs = new ArrayList<>();
    private String ReleaseDate;

    public void subscribe(Subscribers sub){
        subs.add(sub);
    }

    public void unSubscribe(Subscribers sub){
        subs.remove(sub);
    }

    public void notifySubscribers(){
        for (Subscribers sub : subs){
            sub.NewRelease();
        }
    }

    public void release(String ReleaseDate){
        this.ReleaseDate = ReleaseDate;
        notifySubscribers();
    }

    public void sendNewspaper(){
        for (Subscribers sub : subs){
            sub.receiveNewspaper();
        }
    }


}
