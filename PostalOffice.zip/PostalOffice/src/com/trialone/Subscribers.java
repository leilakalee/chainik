package com.trialone;

public class Subscribers implements Observer {
    private String name;
    private String postalcode;
    private PublishersHouse pHouse = new PublishersHouse() ;

    public Subscribers(String name, String postalcode) {
        this.name = name;
        this.postalcode = postalcode;
    }

    @Override
    public void NewRelease(){
        System.out.println( name + ", new release of the newspaper on date is available now!");
    }

    @Override
    public void receiveNewspaper(){
        System.out.println( name + " with postal code " + postalcode + " received newspaper.");
    }

    @Override
    public void subscribePhouse(PublishersHouse pHouseName){
        pHouse=pHouseName;
    }
}
