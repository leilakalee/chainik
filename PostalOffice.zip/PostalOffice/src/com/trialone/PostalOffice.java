package com.trialone;

public class PostalOffice {
    public static void main(String[] args)
    {
        PublishersHouse EgemenQazaqstan = new PublishersHouse();
        Subscribers s1 = new Subscribers("Arman", "140007");
        Subscribers s2 = new Subscribers("Ruslan", "473000");
        Subscribers s3 = new Subscribers("Alma", "100100");

        EgemenQazaqstan.subscribe(s1);
        EgemenQazaqstan.subscribe(s2);
        EgemenQazaqstan.subscribe(s3);

        EgemenQazaqstan.unSubscribe(s2);

        s1.subscribePhouse(EgemenQazaqstan);
        s2.subscribePhouse(EgemenQazaqstan);
        s2.subscribePhouse(EgemenQazaqstan);

        EgemenQazaqstan.release("#21 January 2020");
        EgemenQazaqstan.sendNewspaper();

    }
}
