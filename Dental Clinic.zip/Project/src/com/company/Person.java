package com.company;

public abstract class Person {
    protected int index;
    protected String Name;
    protected String Surname;
    protected String gender;
    protected boolean doctor;

    protected Person(int index, String name, String surname, String gender){
        this.index = index;
        this.Name = name;
        this.Surname = surname;
        this.gender = gender;
        this.doctor = false;
    }

    protected Person() {
        return;
    }
}
