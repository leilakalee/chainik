package com.company;

public interface Rate {
    void adRate(int ra);
    float returnRate();
}
