package com.company;

public class Orthodontists implements profession{
    private String name;
    private String description;

    public Orthodontists(){
        this.name = "Orthodontists";
        this.description = "Specialize in teeth and jaw alignment, using wires, braces, retainers, and other devices.";
    }
    public int setBraces(){
        return 100000;
    }
    public int setBraces(int ex){
        if(ex > 20){
            return 110000;
        }
        else if(ex > 10){
            return 105000;
        }
        else return 100000;
    }
    public int setExpander(){
        return 80000;
    }
    public int setExpander(int ex){
        if(ex > 20){
            return 88000;
        }
        else if(ex > 10){
            return 84000;
        }
        else return 80000;
    }

    @Override
    public String getName() {
        return this.name;
    }


    @Override
    public void showProcedures() {
        System.out.println("Profession: " + this.name);
        System.out.println("Description: " + this.description);
        System.out.println("Procedure: " + "Braces");
        System.out.println("Cost: " + 100000 + " kzt");
        System.out.println("Procedure: " + "Expander");
        System.out.println("Cost: " + 80000 + " kzt");
        System.out.println("+10% to cost, if experience of doctor is more than 20 year, or +5%, if 10");
    }
}
