package com.company;

public interface profession {

    String getName();
    void showProcedures();
}
