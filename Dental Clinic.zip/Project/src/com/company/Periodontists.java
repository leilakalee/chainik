package com.company;

public class Periodontists implements profession {
    private String name;
    private String description;

    public Periodontists (){
        this.name = "Periodontists ";
        this.description = "Help treat and repair diseases and problems of the gums. ";
    }
    public int ProfessionalCleaning(){
        return 2000;
    }
    public int ProfessionalCleaning(int ex){
        if (ex > 20 ){
            return 2200;
        }
        else if(ex > 10){
            return 2100;
        }
        else return  2000;
    }
    public int Bleach(){
        return 20000;
    }
    public int Bleach(int ex){
        if (ex > 20 ){
            return 3600;
        }
        else if(ex > 10){
            return 3300;
        }
        else return  3000;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void showProcedures() {
        System.out.println("Profession: " + this.name);
        System.out.println("Description: " + this.description);
        System.out.println("Procedure: " + "Professional cleaning of 1 teeth");
        System.out.println("Cost: " + 2000 + " kzt");
        System.out.println("Procedure: " + "Bleaching of 1 teeth");
        System.out.println("Cost: " + 3000 + " kzt");
        System.out.println("+20% to cost, if experiences of doctor will more than 20 year, or +10%, if 10");
    }
}
