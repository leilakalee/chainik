package com.company;

public interface procedure {
    boolean register();
    int authorize();
    int form();
    boolean choice(int c);
}
