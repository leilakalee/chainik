package com.company;

public class Doctor extends Person {
    int[] professions = new int[5];
    Rate[] rate = new Rating[100];
    int experience;
    float rating;
    int index;

    public Doctor(int index, String name, String surname, String gender){
        this.index = index;
        this.Name = name;
        this.Surname = surname;
        this.gender = gender;
        this.experience = 0;
        this.doctor = true;
        this.rating = 0;
        this.index=0;
    }
    public void setExperience(int ex){
        this.experience = ex;
    }
    public void setProfessions(int pfs){
        boolean have = false;
        for(int i = 0; i < this.index; i++){
            if(pfs == this.professions[i]){
                have = true;
                break;
            }
        }
        if(have == false){
            this.professions[this.index] = pfs;
            index++;
        }

    }
    public int getExperience(){
        return this.experience;
    }
    public void AddToRate(int rate){
        this.rate[index]=new Rating();
        this.rate[index].adRate(rate);
        this.rating = this.rate[index].returnRate();
    }
    public void showInformation(){
        System.out.println("Name: " + this.Name);
        System.out.println("Surname: " + this.Surname);
        System.out.println("Gender: " + this.gender);
        System.out.println("Experience: " + this.experience + " years");
        System.out.print("Professions: ");
        for(int i=0; i<4; i++){
            if(this.professions[i] == 1){
                GeneralDentist doc = new GeneralDentist();
                System.out.print(doc.getName() + " ");
            }
            else if(this.professions[i] == 2){
                Orthodontists doc = new Orthodontists();
                System.out.print(doc.getName() + " ");
            }
            else if(this.professions[i] == 3){
                Periodontists doc = new Periodontists();
                System.out.print(doc.getName() + " ");
            }
            else if(this.professions[i] == 4){
                Endodontists doc = new Endodontists();
                System.out.print(doc.getName() + " ");
            }
        }
        System.out.println("Rate: " + this.rating);
        System.out.println(" ");
    }
}
