package com.company;

public class Rating implements Rate {
    int count;
    float rate;
    @Override
    public void adRate(int ra) {
        this.rate = ((rate*count)+ra)/(count+1);
        count++;
    }

    @Override
    public float returnRate() {
        return this.rate;
    }
}
