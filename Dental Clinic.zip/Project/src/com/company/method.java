package com.company;
import java.util.Scanner;

public class method implements procedure {
    private Scanner in = new Scanner(System.in);
    private workers w = new workers();
    private Client[] clients = new Client[100];
    private int ic;
    private int cost;
    method(){
        this.ic = 0;
        this.cost = 0;
    }

    @Override
    public boolean register() {
        String user;
        System.out.println("Please create the username");
        user = in.nextLine();
        try {
            if (user.length() > 20 || user.length() < 4) {
                throw new Exception("Incorrect length.");
            }
        } catch (Exception e) {
            System.out.println("Exception is caught. Incorrect length. Try again.");
            return this.register();
        }

        try {
            for (int i = 0; i < ic; i++) {
                if (clients[i].checks(user) == true) {
                    throw new Exception("User with this login already exists.");
                }
            }
        } catch (Exception e) {
            System.out.println("Exception is caught. User with this login already exists. Try again.");
            return this.register();
        }

        System.out.println("Please create a password");
        String pass = in.nextLine();

        try {
            if (pass.length() > 20 || pass.length() < 4) {
                throw new Exception("Incorrect length");
            }
        }
        catch(Exception e){
            System.out.println("Exception is caught. Incorrect length. Try again.");
            return this.register();
        }

        System.out.println("Please re-write password");
        String rePass = in.nextLine();
        try{
        if(!(pass.equals(rePass))){
            throw new Exception("Passwords are not same");

        }
        }
        catch (Exception e){
            System.out.println("Exception is caught. Passwords are not the same. Try again.");
            return this.register();
        }


        System.out.println("Please write your name");
        String name = in.nextLine();
        System.out.println("Please write your surname");
        String surname = in.nextLine();
        System.out.println("Please write your gender");
        String gender = in.nextLine();
        clients[ic] = new Client(ic, name, surname, gender);
        clients[ic].setValues(user, pass);
        System.out.println("You are registered!");
        ic++;
        return true;
    }

    @Override
    public int authorize() {
        String user;
        System.out.println("Please write the username");
        user = in.nextLine();
        int index = 0;
        boolean have = false;
        for(int i=0; i < ic; i++) {
            if (this.clients[i].checks(user) == true) {
                have = true;
                index = i;
                break;
            }
        }
        try {
        if(have == false){
            throw new Exception("User with this login does not exist");
        }
        }
        catch (Exception e){
            System.out.println("Exception is caught. User with this login does not exist. Try again.");
            return this.authorize();
        }

        System.out.println("Please write the password");
        String pass = in.nextLine();
        try{
        if(this.clients[index].check(pass) == false){
            throw new Exception("Password is incorrect.");
        }
        }
        catch (Exception e){
            System.out.println("Exception is caught. Password is incorrect. Try again.");
            return this.authorize();
        }
        System.out.println("You are authorized!");
        return index;
    }

    @Override
    public int form() {
        System.out.println("First of all, you must register and authorize, press 1 - if you want t0 register or 2 - for authorization");
        int choice = in.nextInt();
        int indicator = 0;
        if(choice == 1){
            String user = in.nextLine();
            boolean c = this.register();
            return this.form();
        }
        else if(choice == 2){
            String user = in.nextLine();
            indicator = this.authorize();
        }
        return indicator;
    }

    @Override
    public boolean choice(int c) {
        System.out.println("Now you can choose:");
        System.out.println("1. My profile");
        System.out.println("2. Doctors");
        System.out.println("3. Procedures");
        System.out.println("4. Reserve");
        System.out.println("5. Rate");
        System.out.println("6. Change user");
        System.out.println("7. Exit");
        int choice = in.nextInt();
        if(choice == 1){
            this.clients[c].showInformation();
            return this.choice(c);
        }
        else if(choice == 2){
            this.w.Show();
            return this.choice(c);
        }
        else if(choice == 3){
            this.w.ShowProcedures();
            return this.choice(c);
        }
        else if(choice == 4){
            this.cost = this.w.Zakaz(this.cost, false, false, false, false, false, false, false, false);
            System.out.println("Total: " + this.cost + " kzt");
            System.out.println(" ");
            return this.choice(c);
        }
        else if(choice == 5){
            System.out.println("Choose doctor to rate:");
            System.out.println("1. Kaspiyev Talgat");
            System.out.println("2. Kaliyeva Leila");
            System.out.println("3. Bekbolat Zhangir");
            System.out.println("4. Khamit Zhansaya");
            System.out.println("5. Imasheva Kalamkas");
            int choices = in.nextInt();
            System.out.println("Give rate from 1 to 5");
            int rate = in.nextInt();
            if(rate <= 5 && rate >= 1){
                w.Set(rate, choices - 1);
                return this.choice(c);
            }
            else{
                System.out.println("Incorrect choice");
                return this.choice(c);
            }
        }
        else if(choice == 6){
            this.cost = 0;
            c = this.form();
            return this.choice(c);
        }
        else if(choice == 7){
            return true;
        }
        else{
            System.out.println("Incorrect choice");
            return this.choice(c);
        }
    }
}
