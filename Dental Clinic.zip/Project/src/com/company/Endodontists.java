package com.company;

public class Endodontists implements profession {
    private String name;
    private String description;

    public Endodontists(){
        this.name = "Endodontists";
        this.description = "Deal specifically with issues troubling the nerve of a tooth.";
    }
    public int RegenerativeProcedures(){
        return 5000;
    }
    public int RegenerativeProcedures(int ex){
        if (ex > 20 ){
            return 6000;
        }
        else if(ex > 10){
            return 5500;
        }
        else return  5000;
    }
    public int GumGraftSurgery(){
        return 20000;
    }
    public int GumGraftSurgery(int ex){
        if (ex > 20 ){
            return 24000;
        }
        else if(ex > 10){
            return 22000;
        }
        else return  20000;
    }

    @Override
    public String getName() {
        return this.name;
    }
    @Override
    public void showProcedures() {
        System.out.println("Profession: " + this.name);
        System.out.println("Description: " + this.description);
        System.out.println("Procedure: " + "Regenerative Procedures");
        System.out.println("Cost: " + 5000 + " kzt");
        System.out.println("Procedure: " + "Gum Graft Surgery");
        System.out.println("Cost: " + 20000 + " kzt");
        System.out.println("+20% to cost, if experiences of doctor will more than 20 year, or +10%, if 10");
    }
}
