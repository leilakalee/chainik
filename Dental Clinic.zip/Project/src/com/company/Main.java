package com.company;

import javafx.concurrent.Worker;
import javax.print.Doc;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main {

    public static void main(String[] args) throws SQLException {
        System.out.println("Welcome to Dental Clinic BOBER! ");

        Connection conn = null;
        conn = db.ConnecrDb();
        ResultSet rs;
        rs = conn.createStatement().executeQuery("select * from streets");
        System.out.println("We have three branches in the city of Almaty.");
        while (rs.next()){
            String street = rs.getString(rs.findColumn("st_name"));
            String phone = rs.getString(rs.findColumn("ph_num"));
            System.out.println("address: "+street+" contacts: "+phone);
        }

        procedure Method = new method();
        int c = Method.form();
        boolean d = Method.choice(c);
        System.out.println("Goodbye! See you!");
    }

}
