package com.company;

public class GeneralDentist implements profession {
    private String name;
    private String description;

    public GeneralDentist(){
        this.name = "General Dentist";
        this.description = "Provide regular teeth cleanings and routine dental exams.";
    }
    public int plombage(){
        return 8000;
    }
    public int plombage(int ex){
        if (ex > 20 ){
            return 8800;
        }
        else if(ex > 10){
            return 8400;
        }
        else return  8000;
    }
    public int pullOut(){
        return 3000;
    }
    public int pullOut(int ex){
        if (ex > 20 ){
            return 3600;
        }
        else if(ex > 10){
            return 3300;
        }
        else return  3000;
    }

    @Override
    public String getName() {
        return this.name;
    }
    @Override
    public void showProcedures() {
        System.out.println("Profession: " + this.name);
        System.out.println("Description: " + this.description);
        System.out.println("Procedure: " + "Plombage");
        System.out.println("Cost: " + 8000 + " kzt");
        System.out.println("Procedure: " + "Pull out the tooth");
        System.out.println("Cost: " + 3000 + " kzt");
        System.out.println("+10% to cost, if experiences of doctor will more than 20 year, or +5%, if 10");
    }
}
