package com.company;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class db {
    public static Connection ConnecrDb(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/newdb","newadmin","8695");
            System.out.println("connected");
            return conn;
        } catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
            return null;
        }
    }
}
