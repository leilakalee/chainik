package com.company;

public class Client extends Person{
    private String user;
    private String pass;

    public Client(int ic, String name, String surname, String gender) {
        this.index = index;
        this.Name = name;
        this.Surname = surname;
        this.gender = gender;
        this.doctor = false;
    }
    public void setValues(String user, String pass){
        this.user = user;
        this.pass = pass;
    }
    public boolean check(String pass){
        if(this.pass.equals(pass)){
            return true;
        }
        else return false;
    }
    public boolean checks(String user){
        if(this.user.equals(user)){
            return true;
        }
        return false;
    }

    public void showInformation(){
        System.out.println("Name: " + this.Name);
        System.out.println("Surname: " + this.Surname);
        System.out.println("Gender: " + this.gender);
        System.out.println("Username: " + this.user);
        System.out.println(" ");
    }
}
