package com.company;
import java.util.Scanner;

public class workers{
    private Scanner in = new Scanner(System.in);
    private Doctor[] doc = new Doctor[20];
    private GeneralDentist p1 = new GeneralDentist();
    private Endodontists p2 = new Endodontists();
    private Periodontists p3 = new Periodontists();
    private Orthodontists p4 = new Orthodontists();
    workers(){
        this.doc[0] = new Doctor(0, "Talgat", "Kaspiyev", "male");
        this.doc[0].setExperience(5);
        this.doc[0].setProfessions(2);
        this.doc[0].setProfessions(1);
        this.doc[1] = new Doctor(1, "Leila", "Kaliyeva", "female");
        this.doc[1].setExperience(21);
        this.doc[1].setProfessions(1);
        this.doc[1].setProfessions(2);
        this.doc[1].setProfessions(4);
        this.doc[2] = new Doctor(2, "Zhangir", "Bekbolat", "male");
        this.doc[2].setExperience(12);
        this.doc[2].setProfessions(3);
        this.doc[2].setProfessions(4);
        this.doc[3] = new Doctor(3, "Zhansaya", "Khamit", "female");
        this.doc[3].setExperience(13);
        this.doc[3].setProfessions(1);
        this.doc[3].setProfessions(3);
        this.doc[4] = new Doctor(4, "Kalamkas", "Imasheva", "male");
        this.doc[4].setExperience(7);
        this.doc[4].setProfessions(1);
    }
    public void Set(int number, int index) {
        this.doc[index].AddToRate(number);
    }
    public void Show(){
        for(int i=0; i<=4; i++){
            doc[i].showInformation();
            System.out.println(" ");
        }
    }
    public void ShowProcedures(){
        p1.showProcedures();
        System.out.println(" ");
        p2.showProcedures();
        System.out.println(" ");
        p3.showProcedures();
        System.out.println(" ");
        p4.showProcedures();
        System.out.println(" ");
    }
    public int Zakaz(int cost, boolean p11, boolean p12, boolean p21, boolean p22, boolean p31, boolean p32, boolean p41, boolean p42){
        if(p11 == true && p12 == true && p21 == true && p22 == true && p31 == true && p32 == true && p41 == true && p42 == true){
            System.out.println("You have reserved to all procedures");
        }
        int k;
        System.out.println("Choice procedure: ");
        if(p11 == false) System.out.println("1. Plombage");
        if(p12 == false) System.out.println("2. Pull out the tooth");
        if(p21 == false) System.out.println("3. Regenerative procedures");
        if(p22 == false) System.out.println("4. Gum Graft Surgery");
        if(p31 == false) System.out.println("5. Professional cleaning of 1 teeth");
        if(p32 == false) System.out.println("6. Bleaching of 1 teeth");
        if(p41 == false) System.out.println("7. Braces");
        if(p42 == false) System.out.println("8. Expander");
        System.out.println("9. See details");
        System.out.println("0. Complete reserve");
        int choice = in.nextInt();
        int choices;
        int choose;
        if(choice == 9){
            this.ShowProcedures();
            return this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
        }
        else if(choice == 1 || choice == 2){
            System.out.println("Choose doctor:");
            System.out.println("1. Kaspiyev Talgat");
            System.out.println("2. Kaliyeva Leila");
            System.out.println("4. Khamit Zhansaya");
            System.out.println("5. Imasheva Kalamkas");
            choices = in.nextInt();
            if(choices < 1 || choices > 5 || choices == 3){
                System.out.println("Incorrect choice");
                this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
            }
            System.out.println("Choose amount:");
            choose = in.nextInt();
            if(choose < 1 || choose > 5){
                System.out.println("Incorrect choice");
                return this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
            }
            if(choice == 1){
                cost += choice * this.p1.plombage(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, true, p12, p21, p22, p31, p32, p41, p42);
                System.out.println("Plombage to: " + choice * this.p1.plombage(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
            else{
                cost += choice * this.p1.pullOut(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, p11, true, p21, p22, p31, p32, p41, p42);
                System.out.println("Pull out the tooth to: " + choice * this.p1.pullOut(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
        }
        else if(choice == 3 || choice == 4){
            System.out.println("Choose doctor:");
            System.out.println("1. Kaspiyev Talgat");
            System.out.println("2. Kaliyeva Leila");
            choices = in.nextInt();
            if(choices < 1 || choices > 2){
                System.out.println("Incorrect choice");
                return this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
            }
            if(choice == 3){
                cost += this.p2.RegenerativeProcedures(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, p11, p12, true, p22, p31, p32, p41, p42);
                System.out.println("Regenerative Procedures to: " + this.p2.RegenerativeProcedures(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
            else{
                cost += this.p2.GumGraftSurgery(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, p11, p12, p21, true, p31, p32, p41, p42);
                System.out.println("Gum Graft Surgery to: " + this.p2.GumGraftSurgery(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
        }
        else if(choice == 5 || choice == 6){
            System.out.println("Choose doctor:");
            System.out.println("3. Bekbolat Zhangir");
            System.out.println("4. Khamit Zhansaya");
            choices = in.nextInt();
            if(choices != 3 && choices != 4){
                System.out.println("Incorrect choice");
                return this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
            }
            System.out.println("Choose the number of teeth you want to cure:");
            choose = in.nextInt();
            if(choose < 1 || choose > 5){
                System.out.println("Incorrect choice");
                return this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
            }
            if(choice == 5){
                cost += choice * this.p3.ProfessionalCleaning(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, p11, p12, p21, p22, true, p32, p41, p42);
                System.out.println("Professional cleaning to: " + choice * this.p3.ProfessionalCleaning(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
            else{
                cost += choice * this.p3.Bleach(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, p11, p12 , p21, p22, p31, true, p41, p42);
                System.out.println("Bleaching to: " + choice * this.p3.Bleach(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
        }
        else if(choice == 7 || choice == 8){
            System.out.println("Choose doctor:");
            System.out.println("2. Kaliyeva Leila");
            System.out.println("4. Khamit Zhansaya");
            choices = in.nextInt();
            if(choices != 2 && choices != 4){
                System.out.println("Incorrect choice");
                return this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
            }
            if(choice == 3){
                cost += this.p4.setBraces(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, true);
                System.out.println("Braces to: " + this.p4.setBraces(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
            else{
                cost += this.p4.setExpander(this.doc[choices - 1].getExperience());
                k = this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, true);
                System.out.println("Expander to: " + choice * this.p4.setExpander(this.doc[choices - 1].getExperience()) + " kzt");
                return k;
            }
        }
        else if(choice == 0){
            return cost;
        }
        else{
            System.out.println("Incorrect choice");
            return this.Zakaz(cost, p11, p12, p21, p22, p31, p32, p41, p42);
        }
    }
}
