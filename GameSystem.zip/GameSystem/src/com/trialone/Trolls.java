package com.trialone;

public class Trolls extends Characters {
    public Trolls(){
        super();
        walkingType = new ItWalks();
        flyingType = new CantFly();
    }

}
