package com.trialone;

public interface Actions {
    String fly();
    String walk();
}

class ItFlies implements Actions{
    public String fly() {
        return "I can fly";
    }

    @Override
    public String walk() {
        return null;
    }
}

class CantFly implements Actions{
    public String fly() {
        return "I can't fly";
    }

    @Override
    public String walk() {
        return null;
    }
}

class ItWalks implements Actions{
    public String walk() {
        return "I can walk";
    }

    @Override
    public String fly() {
        return null;
    }


}




