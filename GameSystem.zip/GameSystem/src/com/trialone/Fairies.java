package com.trialone;

public class Fairies extends Characters{
    public Fairies(){
        super();
        flyingType = new ItFlies();
        walkingType = new ItWalks();
    }
}
