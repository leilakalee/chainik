package com.trialone;

public class PlayGame {
    public static void main(String[] args){
        Characters one = new Trolls();
        Characters two = new Pegasus();
        Characters three = new Fairies();

        System.out.println("Troll: " + one.tryToWalk());
        System.out.println("Pegasus: " + two.tryToFly());
        System.out.println("Fairy: " + three.tryToFly() + " and " + three.tryToWalk());
        one.setFlyingAbility(new ItFlies());
        System.out.println("Troll: " + one.tryToFly() + " now using magic!");

    }

}
