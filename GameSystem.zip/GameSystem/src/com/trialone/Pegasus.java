package com.trialone;

public class Pegasus extends Characters {
    public Pegasus(){
        super();
        flyingType = new ItFlies();
    }
}
