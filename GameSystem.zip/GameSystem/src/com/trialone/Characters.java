package com.trialone;

public class Characters {
    public Actions flyingType;
    public Actions walkingType;

    public String tryToFly(){
        return flyingType.fly();
    }

    public String tryToWalk(){
        return walkingType.walk();
    }

    public void setFlyingAbility(Actions newFlyType){
        flyingType = newFlyType;
    }


}
